﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilOOP
{
    internal class Car
    {
       public string _brand;
        public string _type;
        public string _colour;
        public string _year;
        public string _fuel;
        public int _fuel_tank;
        public string _license_plate;
        public int _speed;
        public int _distance_traveled;
        List<int> distances = new List<int>();

        public Engine _engine;
        public Car()
        {
            _brand = "Undefined";
            _type = "Undefined";
            _colour = "Undefined";
            _year = "Undefined";
            _fuel = "Undefined";
            _fuel_tank = 0;
            _license_plate = "Undefined";
            _speed = 0;
            _distance_traveled = 0;
            _engine = new Engine();
        }

        public Car(string brand, string type, string colour, string year, string fuel, int fuel_tank, string license_plate, int speed, int distance_traveled, int hp, int cylinders, int cylinder_volume, string manufacturer)
        {
            _brand = brand;
            _type = type;
            _colour = colour;
            _year = year;
            _fuel = fuel;
            _fuel_tank = fuel_tank;
            _license_plate = license_plate;
            _speed = speed;
            _distance_traveled = distance_traveled;

            _engine = new Engine(hp, cylinders, cylinder_volume, manufacturer);
        }
        public Car(int speed, string brand, string type, string colour, string year, string fuel, int fuel_tank, string license_plate, int distance_traveled, int hp, int cylinders, int cylinder_volume, string manufacturer)
        {
            _brand = brand;
            _type = type;
            _colour = colour;
            _year = year;
            _fuel = fuel;
            _fuel_tank = fuel_tank;
            _license_plate = license_plate;
            _speed = speed;
            _distance_traveled = distance_traveled;

            _engine = new Engine(hp, cylinders, cylinder_volume, manufacturer);

        }
        public Car(int speed, int distance_traveled, string brand, string type, string colour, string year, string fuel, int fuel_tank, string license_plate, int hp, int cylinders, int cylinder_volume, string manufacturer)
        {
            _brand = brand;
            _type = type;
            _colour = colour;
            _year = year;
            _fuel = fuel;
            _fuel_tank = fuel_tank;
            _license_plate = license_plate;
            _speed = speed;
            _distance_traveled = distance_traveled;

            _engine = new Engine(hp, cylinders, cylinder_volume, manufacturer);

        }

        public void Print()
        {
            Console.WriteLine($"{_brand}:{_type}:{_colour}:{_year}:{_fuel}:{_fuel_tank}:{_license_plate}:{_speed}:{_distance_traveled}");
        }

        public void Honk()
        {
            Console.Write("Tut Tut");
        }

        public void Drive()
        {
            //_distance_traveled = _speed * 2;
            _fuel_tank = _fuel_tank - _speed;
           // Console.WriteLine($"Distance traveled:{_distance_traveled}");
           // Console.WriteLine($"Fuel left: {_fuel_tank}");
        }
        public void Brake()
        {
            _speed = _speed - 5;
            _distance_traveled = _distance_traveled - _speed/2;
        }
        public void Acc()
        {
            _speed = _speed + 5;
            _distance_traveled = _distance_traveled + _speed*2;
        }
        public void CurrentSpeed()
        {
            Console.WriteLine(_speed);
        }
        //Console.ReadKey();
        //Thread.Sleep();
        public void DistanceTraveled()
        {
            Console.WriteLine(_distance_traveled);
            distances.Add(_distance_traveled);
        }

        public void LongestDistance()
        {
            int longest = distances[0];

            for (int i = 0; i < distances.Count; i++)
            {
                if (distances[i+1] < longest)
                {
                    longest = distances[i+1];
                }
            }
            Console.WriteLine(longest);
        }

        public string ConvertToString()
        {
            return $"{_brand}\n{_type}\n{_colour}\n{_year}\n{_fuel}\n{_fuel_tank}\n{_license_plate}\n{_speed}\n{_distance_traveled}";
        }

        //public override string ToString()
        //{
        //    return $"{_brand}\n{_type}";
        //}

    }




}
