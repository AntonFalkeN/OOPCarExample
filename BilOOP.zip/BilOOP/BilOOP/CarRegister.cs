﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilOOP
{
    internal class CarRegister
    {
         List<Car> _CarRegisterList = new List<Car>();
        public void AddCar(Car CarToAdd, string _license_plate)
        {
            bool chek = SearchForDubble(_license_plate);
            if (chek == true)
                Console.WriteLine("Fordonet finns redan registrerat");
            else
            _CarRegisterList.Add(CarToAdd);
        }

        public void RemoveCar(List<string> _CarRegisterList, string carToRemove)
        {

        }

        public bool SearchForCar()
        {
            Console.WriteLine("Vad vill du söka efter?");
            string searchWord = Console.ReadLine();

            bool chek = false;
                for (int i = 0; i < _CarRegisterList.Count; i++)
                {
                    string name = _CarRegisterList[i].ConvertToString();
                if (name.Contains(searchWord))
                {
                    chek = true;
                    Console.WriteLine($"Den finns\n{_CarRegisterList[i].ConvertToString()}");
                }
                }
            return chek;
        }
        public bool SearchForDubble(string searchWord)
        {
            bool chek = false;
            for (int i = 0; i < _CarRegisterList.Count; i++)
            {
                string name = _CarRegisterList[i].ConvertToString();
                if (name.Contains(searchWord))
                {
                    chek = true;
                    Console.WriteLine($"Den finns\n{_CarRegisterList[i].ConvertToString()}");
                }
            }
            return chek;
        }
        /*
        public bool SearchInRegister(CarRegister reg)
        {
            Console.WriteLine("Vad vill du söka efter?");
            string searchWord = Console.ReadLine();
            bool chek = reg.SearchForCar(searchWord);
            /*
            for (int i = 0; i < reg._CarRegisterList.Count; i++)
            {
                if(reg._CarRegisterList[i].ConvertToString().Contains(searchWord))
                    Console.WriteLine(reg._CarRegisterList[i].ConvertToString());
            }
            
            return chek;
        }
            */
        static void WriteToFile(Car c2, string filename)
        {
            try
            {
                StreamWriter sw = new StreamWriter(filename);

                sw.WriteLine(c2.ConvertToString());
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
            }
        }
        static List<string> ReadFile(string filename)
        {
            List<string> rowsInFile = new List<string>();
            String line;
            try
            {
                StreamReader sr = new StreamReader(filename);
                line = sr.ReadLine();

                while (line != null)
                {
                    line = sr.ReadLine();
                    rowsInFile.Add(line);
                }

                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {

            }

            return rowsInFile;
        }

    }
}
