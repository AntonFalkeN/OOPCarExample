﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilOOP
{
    internal class Engine
    {
        int _hp;
        int _cylinders;
        int _cylinder_volume;
        string _manufacturer;
        public Engine()
        {
             _hp = 0;
            _cylinders = 0;
            _cylinder_volume = 0;
            _manufacturer = "Unknown";
        }

        public Engine(int hp, int cylinders, int cyliner_volume, string manufacturer)
        {
            _hp = hp;
            _cylinders = cylinders;
            _cylinder_volume = cyliner_volume;
            _manufacturer = manufacturer;
        }

    }
}
