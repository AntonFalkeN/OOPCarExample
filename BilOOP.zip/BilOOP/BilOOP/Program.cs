﻿using System.Security.Cryptography.X509Certificates;

namespace BilOOP
{
    internal class Program
    {

        /*
         * Vad gör en kompilator?
         * Koden (källkoden) transformeras till maskinkod som datorn kan använda
         * 
         * 
         *AcessModifier. bestämmer vad i klasserna de kan hantera i andra klasser, ex. public, allt kan komma åt allt
         *Vi måste begränsa vem som får göra vad men också hur, private ger endast klassen åtkomst till variabler
         * Variabeln name är privat men metoden GetName är public. 
         *
         *
         *

        public string GetName()
        {
            return name;
        }
        Skapa objekt av klasser är att skapa en instans
        Skillnad på class och objekt

        internal

        */
        public static int GetRandom()
        {
            Random random = new Random();
            int number = random.Next(1, 3);
            return number;
        }
        public static void RandomAction(Car c)
        {
            int number = GetRandom();
            if (number == 1)
                c.Acc();
            else
                c.Brake();
        }
        public static void Race(Car c1, Car c2, Car c3)
        {
            for (int i = 0; i < 100; i++)
            {
                RandomAction(c3);
                RandomAction(c2);
                RandomAction(c1);
                c1.Drive();
                c2.Drive();
                c3.Drive();

            }
            c1.DistanceTraveled();
            c2.DistanceTraveled();
            c3.DistanceTraveled();
        }
        public static void Register()
        {
            Console.WriteLine("Vilket märke har hojen?");
            string brand = Console.ReadLine();
            Console.WriteLine($"Vilken modell är din {brand}?");
            string model = Console.ReadLine();
            Console.WriteLine($"Vilken färg har din {brand}{model}?");
            string colour = Console.ReadLine();
            Console.WriteLine("Vilken årsmodell är det?");
            string year = Console.ReadLine();
            int.Parse(year);
            Console.WriteLine($"Hur stor tank har din motorcykel?");
            string size = Console.ReadLine();
            int.Parse(size);
            Console.WriteLine($"Vilket regnummer har hojen?");
            string licensePlate = Console.ReadLine();
            Console.WriteLine("Vilken hastighet?");
            string speed = Console.ReadLine();
            int.Parse(speed);
            Console.WriteLine("Hur många mil har körts?");
            string disntace = Console.ReadLine();
            int.Parse(disntace);
        }
 
        static void Main(string[] args)
        {
            CarRegister carReg = new();
            CarRegister mcReg = new();

            mcReg.AddCar(new Car(), "Undefined");
            carReg.AddCar(new Car(), "Undefined");


            Car c1 = new Car();
            Car c2 = new Car("Suzuki", "GSX-R", "Black/Red", "2019", "Petrol", 11, "TEO545", 50, 0, 15, 1, 124, "Suzuki Motor Corporation");
            Car test = new Car("Suzuki", "GSX-R", "Black/Red", "2019", "Petrol", 11, "TEO545", 50, 0, 15, 1, 124, "Suzuki Motor Corporation");

            Car c3 = new Car(70, "Ducati", "Panigale V4-S", "Red", "2023", "Petrol", 15, "AGG666", 0,231, 4, 1103, "Ducati");
            Car c4 = new Car(100, 0, "Ninja-H2", "Kawasaki", "Silver", "2018", "Petrol", 10, "UWU527", 200, 4, 998, "Kawasaki");
            //CarRegister.WriteToFile(c2, "MotorcykelReg");

            c1.Print();
            c2.Print();
            c3.Print();
            c4.Print();

            //Race(c1, c2, c3);
            mcReg.AddCar(c2,c2._license_plate);
            mcReg.AddCar(test, test._license_plate);
            mcReg.SearchForCar();
        }

    }
}